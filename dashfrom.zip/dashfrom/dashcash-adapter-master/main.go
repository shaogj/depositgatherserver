package main

import (
	"fmt"
	"github.com/assetsadapterstore/dashcash-adapter/dashcash"
)

func main() {
	fmt.Printf("%s adapter build", dashcash.Symbol)
}
